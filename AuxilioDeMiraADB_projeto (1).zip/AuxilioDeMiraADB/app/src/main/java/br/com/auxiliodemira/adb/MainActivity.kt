package br.com.auxiliodemira.adb

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(15, 15, 18)
    private val panel = Color.rgb(29, 29, 35)
    private val red = Color.rgb(190, 35, 45)
    private val white = Color.WHITE
    private val muted = Color.rgb(175, 175, 185)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildScreen()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(24))
            setBackgroundColor(bg)
        }
        scroll.addView(page)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "AUXÍLIO DE MIRA"
            textSize = 25f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        page.addView(title, matchWrap())
        val subtitle = TextView(this).apply {
            text = "( A D B )  •  PAINEL ANDROID"
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(7), 0, dp(22))
        }
        page.addView(subtitle, matchWrap())

        section(page, "AJUSTES DE TREINAMENTO")
        addSwitch(page, "Ajustes personalizados", "Guia de configuração e prática.", false)
        addSwitch(page, "Evitar ultrapassar o alvo", "Lembrete para controlar o arrasto manual da mira.", false)
        addSwitch(page, "Treino de estabilidade", "Ativa um modo de orientação dentro deste painel.", false)

        section(page, "DEPURAÇÃO WI-FI / ADB")
        val adbInfo = TextView(this).apply {
            text = "O Android exige que o pareamento ADB seja autorizado nas configurações do sistema. Este protótipo abre as configurações; ainda não implementa um cliente ADB nem executa comandos no jogo."
            textSize = 13f
            setTextColor(muted)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(panel, 14)
        }
        page.addView(adbInfo, matchWrap())
        addButton(page, "ABRIR OPÇÕES DO DESENVOLVEDOR", panel) {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }

        section(page, "ABRIR JOGO")
        addButton(page, "FREE FIRE", red) { launchGame("com.dts.freefireth") }
        addButton(page, "FREE FIRE MAX", red) { launchGame("com.dts.freefiremax") }

        val footer = TextView(this).apply {
            text = "Este aplicativo não altera a mira dentro do Free Fire, não automatiza disparos e não garante ausência de punições. As opções acima são controles locais de orientação."
            textSize = 11f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(20), dp(8), 0)
        }
        page.addView(footer, matchWrap())
    }

    private fun section(parent: LinearLayout, text: String) {
        val label = TextView(this).apply {
            this.text = text
            textSize = 12f
            setTextColor(red)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(2, dp(20), 0, dp(10))
        }
        parent.addView(label, matchWrap())
    }

    private fun addSwitch(parent: LinearLayout, label: String, description: String, initial: Boolean) {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(panel, 14)
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val name = TextView(this).apply {
            text = label
            textSize = 15f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val toggle = Switch(this).apply {
            isChecked = initial
            buttonTintList = null
        }
        row.addView(toggle)
        wrap.addView(row, matchWrap())
        val desc = TextView(this).apply {
            text = description
            textSize = 11f
            setTextColor(muted)
            setPadding(0, dp(5), 0, 0)
        }
        wrap.addView(desc, matchWrap())
        toggle.setOnCheckedChangeListener { _, checked ->
            Toast.makeText(this, if (checked) "Opção ativada neste painel" else "Opção desativada", Toast.LENGTH_SHORT).show()
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(9)
        parent.addView(wrap, lp)
    }

    private fun addButton(parent: LinearLayout, text: String, color: Int, action: () -> Unit) {
        val button = Button(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(white)
            isAllCaps = false
            background = rounded(color, 14)
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(-1, dp(54))
        lp.bottomMargin = dp(10)
        parent.addView(button, lp)
    }

    private fun launchGame(packageName: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) startActivity(launch)
        else Toast.makeText(this, "Esse jogo não está instalado neste aparelho.", Toast.LENGTH_LONG).show()
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
