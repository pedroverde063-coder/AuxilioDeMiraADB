# AUXÍLIO DE MIRA (ADB)

Projeto inicial Android em Kotlin, com interface escura e botões para abrir as configurações do desenvolvedor e iniciar Free Fire / Free Fire MAX.

## Abrir no Android Studio
1. Extraia o ZIP.
2. Abra a pasta `AuxilioDeMiraADB` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Conecte um aparelho Android e use Run, ou gere um APK em Build > Build Bundle(s) / APK(s) > Build APK(s).

## Estado deste protótipo
- Interface e opções locais de treinamento: implementadas.
- Atalhos para Free Fire (`com.dts.freefireth`) e Free Fire MAX (`com.dts.freefiremax`): implementados.
- Atalho para Opções do desenvolvedor: implementado.
- Pareamento ADB real: ainda não implementado. Um app comum não ganha acesso ADB só por abrir Depuração sem fio; é necessário implementar um cliente/protocolo ADB e passar pelo pareamento autorizado do Android.
- As opções não alteram a mira dentro do jogo. Não há promessa de evitar banimento.

## Requisitos
- Android Studio com Android SDK 35.
- JDK 17.
- Android 8.0 ou superior para instalar o protótipo.
